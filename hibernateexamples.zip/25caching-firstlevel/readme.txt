Add the following jars which are present in optional jars folder

1) ehcache-core-2.4.3
2) hibernate-ehcache-4.3.5.Final
3) slf4j-api-1.6.1