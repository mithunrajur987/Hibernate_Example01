
 Use org.hibernate.dialect.MySQLDialect 
 as dialect class for any version of MySQL database 

 
